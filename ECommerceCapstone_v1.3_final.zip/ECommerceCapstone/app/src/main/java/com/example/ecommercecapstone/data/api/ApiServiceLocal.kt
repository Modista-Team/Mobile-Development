package com.example.ecommercecapstone.data.api

import com.example.ecommercecapstone.data.RecommendationRequest
import com.example.ecommercecapstone.data.api.response.RecommendationResponse
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.POST

interface ApiServiceLocal {
    @POST("recommend")
    fun getRecommendation(
        @Body recommendationRequest: RecommendationRequest
    ): Call<RecommendationResponse>
}