package com.example.ecommercecapstone.ui.profil

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.ecommercecapstone.data.UserRepository
import kotlinx.coroutines.launch

class ProfilViewModel(private val repository: UserRepository) : ViewModel() {

    // Fungsi logout yang akan dipanggil dari Fragment
    fun logout() {
        viewModelScope.launch {
            repository.logout()
        }
    }
}
