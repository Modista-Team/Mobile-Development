package com.example.ecommercecapstone.ui.register

import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.animation.AnimationUtils
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.ecommercecapstone.R
import com.example.ecommercecapstone.data.ResultState
import com.example.ecommercecapstone.databinding.ActivityRegisterBinding
import com.example.ecommercecapstone.ui.RegisterViewModelFactory
import com.example.ecommercecapstone.ui.login.LoginActivity

class RegisterActivity : AppCompatActivity() {
    private val viewModel by viewModels<RegisterViewModel> {
        RegisterViewModelFactory.getInstance()
    }
    private lateinit var binding: ActivityRegisterBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.hide()

        setupAction()
        applyAnimations()
    }

    private fun setupAction() {
        val drawable = binding.btnSwitchLogin.background as GradientDrawable
        drawable.setColor(ContextCompat.getColor(this, R.color.inactive))

        binding.btnSwitchLogin.setOnClickListener {
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
        }

        binding.btnReg.setOnClickListener { register() }

        binding.editTextTextPassword.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                // No operation
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                // No operation
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                if (s.toString().length < 8) {
                    binding.editTextTextPassword.error = "Password tidak boleh kurang dari 8 karakter"
                } else {
                    binding.editTextTextPassword.error = null
                }
            }
        })
    }

    private fun register() {
        val first_name = binding.editTextNamaDepan.text.toString()
        val last_name = binding.editTextNamaBelakang.text.toString()
        val username = binding.editTextNamaPengguna.text.toString()
        val phone = binding.editTextNomorTelepon.text.toString()
        val address = binding.editTextAlamat.text.toString()
        val email = binding.editTextTextEmail.text.toString()
        val password = binding.editTextTextPassword.text.toString()

        viewModel.register(first_name, last_name, username, phone, address, email, password).observe(this) { result ->
            if (result != null) {
                when (result) {
                    is ResultState.Loading -> {
                        showLoading(true)
                    }

                    is ResultState.Success -> {
                        showToast(result.data.message) // Assuming RegisterResponse has a message field
                        showLoading(false)
                        // Handle successful registration (e.g., navigate to login screen)
                        AlertDialog.Builder(this).apply {
                            setTitle("Yeah!")
                            setMessage("Akun dengan $email sudah jadi nih. Yuk, login.")
                            setPositiveButton("Lanjut") { _, _ ->
                                finish()
                            }
                            create()
                            show()
                        }
                    }

                    is ResultState.Error -> {
                        showToast(result.error)
                        showLoading(false)
                    }
                }
            }
        }
    }

    private fun showLoading(isLoading: Boolean) {
        binding.progressIndicator.visibility = if (isLoading) View.VISIBLE else View.GONE
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    private fun applyAnimations() {
        val slideInFromBottom = AnimationUtils.loadAnimation(this, R.anim.slide_in_from_bottom)

        binding.linearLayout5.startAnimation(slideInFromBottom)
        binding.layoutBtn.startAnimation(slideInFromBottom)
        binding.textInputLayoutNamaDepan.startAnimation(slideInFromBottom)
        binding.textInputLayoutNamaBelakang.startAnimation(slideInFromBottom)
        binding.textInputLayoutNomorTelepon.startAnimation(slideInFromBottom)
        binding.textInputLayoutEmail.startAnimation(slideInFromBottom)
        binding.textInputLayoutPassword.startAnimation(slideInFromBottom)
        binding.btnReg.startAnimation(slideInFromBottom)
    }
}
