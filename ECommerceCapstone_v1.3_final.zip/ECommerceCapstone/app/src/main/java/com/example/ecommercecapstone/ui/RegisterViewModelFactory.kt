package com.example.ecommercecapstone.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.ecommercecapstone.data.RegisterRepository
import com.example.ecommercecapstone.di.RegisterInjection
import com.example.ecommercecapstone.ui.register.RegisterViewModel

class RegisterViewModelFactory(private val repository: RegisterRepository) : ViewModelProvider.NewInstanceFactory() {

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return when {
            modelClass.isAssignableFrom(RegisterViewModel::class.java) -> {
                RegisterViewModel(repository) as T
            }
            else -> throw IllegalArgumentException("Unknown ViewModel class: " + modelClass.name)
        }
    }

    companion object {
        @Volatile
        private var instance: RegisterViewModelFactory? = null

        @JvmStatic
        fun getInstance() =
            instance ?: synchronized(this) {
                instance ?: RegisterViewModelFactory(RegisterInjection.provideRepository())
            }.also { instance = it }
    }
}