package com.example.ecommercecapstone.ui.detailProduk

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.bumptech.glide.Glide
import com.example.ecommercecapstone.data.RecommendationRequest
import com.example.ecommercecapstone.data.adapter.RecommendationAdapter
import com.example.ecommercecapstone.data.api.ApiConfig
import com.example.ecommercecapstone.databinding.ActivityDetailProdukBinding
import com.example.ecommercecapstone.ui.ViewModelFactory
import com.example.ecommercecapstone.ui.checkout.CheckoutActivity
import com.example.ecommercecapstone.ui.main.MainActivity
import kotlin.properties.Delegates

class DetailProdukActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailProdukBinding
    private var id by Delegates.notNull<Int>()
    private val viewModel by viewModels<DetailProdukViewModel> {
        ViewModelFactory.getInstance(this)
    }

    private lateinit var recommendationAdapter: RecommendationAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailProdukBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.hide()

        setupAction()
        setupViewModel()
        viewModel.recommendations.observe(this) { recommendations ->
            recommendationAdapter.updateData(recommendations)
        }
        setupRecyclerView()

        id = intent.getIntExtra("id", 0)

        binding.closeButton.setOnClickListener{ close() }
    }

    private fun setupAction(){
        binding.btnBeli.setOnClickListener{
            val intent = Intent(this, CheckoutActivity::class.java)
            startActivity(intent)
        }
    }

    private fun setupViewModel() {
        val product = "336"
        val Product_ID = 336
        val Product_Description = "Knitwear"
        val Product_Category = "Sports"
        val Product_Line = "Tops"
        val Raw_Material = "Polyester"
        val Unit_Price = 22.44

        viewModel.isLoading.observe(this) {
            binding.progressBar.visibility = if (it.equals(true)) View.VISIBLE else View.GONE
        }

        viewModel.getSession().observe(this) { user ->
            if (user.token != null) {
                ApiConfig.setAuthToken(user.token)
                Log.d("DEBUGGING", user.token)
                viewModel.getDetailProduct(this.id)
                // Add this line to fetch recommendations
                viewModel.fetchRecommendations(RecommendationRequest(product, Product_ID, Product_Description, Product_Category, Product_Line, Raw_Material, Unit_Price))
            }
        }

        viewModel.detailProductName.observe(this){
            binding.tvNamaProduk.text = it
        }

        viewModel.detailProductStock.observe(this){
            binding.tvStokQty.text = it.toString()
        }

        viewModel.detailProductPrice.observe(this){
            binding.tvHarga.text = it
        }

        viewModel.detailProductDescription.observe(this){
            binding.tvIsiDeskripsi.text = it
        }

        viewModel.detailProductPhotoUrl.observe(this){
            Glide.with(this)
                .load(it)
                .into(binding.detailPhoto)
        }
    }

    private fun setupRecyclerView() {
        recommendationAdapter = RecommendationAdapter(emptyList()) // Initially, set an empty list
        binding.rvRekomendasi.apply {
            adapter = recommendationAdapter
            layoutManager = LinearLayoutManager(this@DetailProdukActivity, LinearLayoutManager.HORIZONTAL, false)
        }
    }

    private fun close() {
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
    }

    companion object {
        const val ID = "id"
    }
}