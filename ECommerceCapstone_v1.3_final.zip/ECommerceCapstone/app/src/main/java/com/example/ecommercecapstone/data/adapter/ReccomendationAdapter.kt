package com.example.ecommercecapstone.data.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.ecommercecapstone.data.api.response.ListRecommendation
import com.example.ecommercecapstone.databinding.ItemRowRekomendasiBinding

class RecommendationAdapter(private var recommendations: List<ListRecommendation>) : RecyclerView.Adapter<RecommendationAdapter.ViewHolder>() {

    fun updateData(newRecommendations: List<ListRecommendation>) {
        recommendations = newRecommendations
        notifyDataSetChanged()
    }

    class ViewHolder(private val binding: ItemRowRekomendasiBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(recommendation: ListRecommendation) {
            binding.apply {
                // Bind data to your views here
                tvItemName.text = recommendation.productDescription
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemRowRekomendasiBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(recommendations[position])
    }

    override fun getItemCount(): Int = recommendations.size
}
