package com.example.ecommercecapstone.data.api

import com.example.ecommercecapstone.data.api.response.DetailProductResponse
import com.example.ecommercecapstone.data.api.response.DetailUserResponse
import com.example.ecommercecapstone.data.api.response.LoginResponse
import com.example.ecommercecapstone.data.api.response.ProductResponse
import com.example.ecommercecapstone.data.api.response.RegisterResponse
import retrofit2.Call
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path

interface ApiService {
    @FormUrlEncoded
    @POST("login")
    suspend fun login(
        @Field("email") email: String,
        @Field("password") password: String
    ): LoginResponse

    @FormUrlEncoded
    @POST("register")
    suspend fun register(
        @Field("first_name") first_name: String,
        @Field("last_name") last_name: String,
        @Field("username") username: String,
        @Field("phone") phone: String,
        @Field("address") address: String,
        @Field("email") email: String,
        @Field("password") password: String
    ): RegisterResponse

    @GET("products")
    fun getProducts(): Call<List<ProductResponse>>

    @GET("products/{product_id}")
    fun getDetailProduct(
        @Path("product_id") id: Int
    ): Call<DetailProductResponse>

    @GET("users/{user_id}")
    fun getDetailUser(
        @Path("user_id") id: Int
    ): Call<DetailUserResponse>
}