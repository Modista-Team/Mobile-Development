package com.example.ecommercecapstone.data

import com.example.ecommercecapstone.data.pref.UserModel
import com.example.ecommercecapstone.data.pref.UserPreference
import kotlinx.coroutines.flow.Flow

class UserRepository private constructor(
    private val userPreference: UserPreference
) {

    // Fungsi untuk menyimpan sesi pengguna
    suspend fun saveSession(user: UserModel) {
        userPreference.saveSession(user)
    }

    // Fungsi untuk mendapatkan sesi pengguna sebagai Flow
    fun getSession(): Flow<UserModel> {
        return userPreference.getSession()
    }

    // Fungsi untuk melakukan logout pengguna
    suspend fun logout() {
        userPreference.logout()
    }

    companion object {
        @Volatile
        private var instance: UserRepository? = null

        // Mendapatkan instance dari UserRepository dengan singleton pattern
        fun getInstance(userPreference: UserPreference): UserRepository =
            instance ?: synchronized(this) {
                instance ?: UserRepository(userPreference)
            }.also { instance = it }
    }
}
