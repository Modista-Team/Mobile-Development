package com.example.ecommercecapstone.ui.login

import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.animation.AnimationUtils
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.ecommercecapstone.R
import com.example.ecommercecapstone.data.api.ApiConfig
import com.example.ecommercecapstone.data.pref.UserModel
import com.example.ecommercecapstone.databinding.ActivityLoginBinding
import com.example.ecommercecapstone.ui.ViewModelFactory
import com.example.ecommercecapstone.ui.main.MainActivity
import com.example.ecommercecapstone.ui.register.RegisterActivity
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking

class LoginActivity : AppCompatActivity() {

    private val viewModel by viewModels<LoginViewModel> {
        ViewModelFactory.getInstance(this)
    }
    private lateinit var binding: ActivityLoginBinding
    private lateinit var googleSignInClient: GoogleSignInClient
    private lateinit var firebaseAuth: FirebaseAuth

    private val googleSignInLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
        if (task.isSuccessful) {
            val account = task.result
            val credential = GoogleAuthProvider.getCredential(account.idToken, null)
            firebaseAuth.signInWithCredential(credential)
                .addOnCompleteListener { authTask ->
                    if (authTask.isSuccessful) {
                        val user = firebaseAuth.currentUser
                        user?.let {
                            val userModel = UserModel(it.email ?: "", it.uid, true)
                            viewModel.saveSession(userModel)
                            showSuccessDialog()
                        }
                    } else {
                        showErrorDialog("Google Sign-In failed.")
                    }
                }
        } else {
            showErrorDialog("Google Sign-In failed.")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.hide()

        // Initialize Firebase Auth
        firebaseAuth = FirebaseAuth.getInstance()

        // Configure Google Sign-In
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(getString(R.string.default_web_client_id))
            .requestEmail()
            .build()

        googleSignInClient = GoogleSignIn.getClient(this, gso)

        setupAction()
        applyAnimations()
    }

    private fun setupAction() {
        val drawable = binding.btnSwitchReg.background as GradientDrawable
        drawable.setColor(ContextCompat.getColor(this, R.color.inactive))

        binding.btnSwitchReg.setOnClickListener {
            val intent = Intent(this, RegisterActivity::class.java)
            startActivity(intent)
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
        }

        binding.btnLogin.setOnClickListener {
            val email = binding.editTextTextEmail.text.toString()
            val password = binding.editTextTextPassword.text.toString()

            // Your existing login logic here
            runBlocking {
                launch {
                    try {
                        val response = ApiConfig.getApiService().login(email, password)
                        if (response.message == "Login successful") {
                            val user = UserModel(email, response.token, true)
                            viewModel.saveSession(user)
                            showSuccessDialog()
                        } else {
                            showErrorDialog("Login failed. Please try again.")
                        }
                    } catch (e: Exception) {
                        showErrorDialog("Login failed. Please try again.")
                    }
                }
            }
        }

        binding.tvLogin.setOnClickListener {
            signInWithGoogle()
        }

        // Add TextWatcher for password validation
        binding.editTextTextPassword.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                // No operation
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                // No operation
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                if (s.toString().length < 8) {
                    binding.editTextTextPassword.error = "Password tidak boleh kurang dari 8 karakter"
                } else {
                    binding.editTextTextPassword.error = null
                }
            }
        })
    }

    private fun applyAnimations() {
        val slideInFromBottom = AnimationUtils.loadAnimation(this, R.anim.slide_in_from_bottom)

        binding.bg.startAnimation(slideInFromBottom)
        binding.layoutBtn.startAnimation(slideInFromBottom)
        binding.linearLayoutForm.startAnimation(slideInFromBottom)
        binding.linearLayoutEmail.startAnimation(slideInFromBottom)
        binding.editTextTextEmail.startAnimation(slideInFromBottom)
        binding.linearLayoutPassword.startAnimation(slideInFromBottom)
        binding.textInputLayoutPassword.startAnimation(slideInFromBottom)
        binding.editTextTextPassword.startAnimation(slideInFromBottom)
        binding.linearLayout2.startAnimation(slideInFromBottom)
        binding.cv.startAnimation(slideInFromBottom)
        binding.tvLogin.startAnimation(slideInFromBottom)
        binding.linearLayout3.startAnimation(slideInFromBottom)
        binding.btnLogin.startAnimation(slideInFromBottom)
        binding.line.startAnimation(slideInFromBottom)
    }

    private fun signInWithGoogle() {
        val signInIntent = googleSignInClient.signInIntent
        googleSignInLauncher.launch(signInIntent)
    }

    private fun showSuccessDialog() {
        AlertDialog.Builder(this).apply {
            setTitle("Yeah!")
            setMessage("Anda berhasil login")
            setPositiveButton("Lanjut") { _, _ ->
                val intent = Intent(context, MainActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
                startActivity(intent)
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
                finish()
            }
            create()
            show()
        }
    }

    private fun showErrorDialog(message: String) {
        AlertDialog.Builder(this).apply {
            setTitle("Error")
            setMessage(message)
            setPositiveButton("OK", null)
            create()
            show()
        }
    }
}
