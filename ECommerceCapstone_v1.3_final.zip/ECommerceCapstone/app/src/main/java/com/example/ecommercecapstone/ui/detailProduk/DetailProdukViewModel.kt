package com.example.ecommercecapstone.ui.detailProduk

import android.content.ContentValues
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import com.example.ecommercecapstone.data.RecommendationRequest
import com.example.ecommercecapstone.data.UserRepository
import com.example.ecommercecapstone.data.api.ApiConfig
import com.example.ecommercecapstone.data.api.ApiConfigLocal
import com.example.ecommercecapstone.data.api.response.DetailProductResponse
import com.example.ecommercecapstone.data.api.response.ListRecommendation
import com.example.ecommercecapstone.data.api.response.RecommendationResponse
import com.example.ecommercecapstone.data.pref.UserModel
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class DetailProdukViewModel (private val repository: UserRepository) : ViewModel() {
    private val _detailProductName = MutableLiveData<String>()
    val detailProductName: LiveData<String> = _detailProductName

    private val _detailProductDescription = MutableLiveData<String>()
    val detailProductDescription: LiveData<String> = _detailProductDescription

    private val _detailProductPhotoUrl = MutableLiveData<String>()
    val detailProductPhotoUrl: LiveData<String> = _detailProductPhotoUrl

    private val _detailProductId = MutableLiveData<Int>()

    private val _detailProductPrice = MutableLiveData<String>()
    val detailProductPrice: LiveData<String> = _detailProductPrice

    private val _detailProductStock = MutableLiveData<Int>()
    val detailProductStock: LiveData<Int> = _detailProductStock

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    private val _recommendations = MutableLiveData<List<ListRecommendation>>()
    val recommendations: LiveData<List<ListRecommendation>> get() = _recommendations

    init {
        _detailProductId.value?.let { getDetailProduct(it) }
    }

    fun getDetailProduct(id: Int) {
        _isLoading.value = true
        val client = ApiConfig.getApiService().getDetailProduct(id)
        client.enqueue(object: Callback<DetailProductResponse> {
            override fun onResponse(
                call: Call<DetailProductResponse>,
                response: Response<DetailProductResponse>
            ) {
                if (response.isSuccessful) {
                    val responseBody = response.body()
                    _isLoading.value = false

                    _detailProductName.value = responseBody?.productName.toString()
                    _detailProductId.value = responseBody?.productId
                    _detailProductStock.value = responseBody?.stock
                    _detailProductPrice.value = responseBody?.price.toString()
                    _detailProductDescription.value = responseBody?.description.toString()
                    _detailProductPhotoUrl.value = responseBody?.imageUrl.toString()
                } else {
                    _isLoading.value = false
                }
            }
            override fun onFailure(call: Call<DetailProductResponse>, t: Throwable) {
                _isLoading.value = false
                Log.e(TAG, "onFailure: ${t.message}")
            }
        })
    }

    // Function to get user session
    fun getSession(): LiveData<UserModel> {
        return repository.getSession().asLiveData()
    }

    fun fetchRecommendations(request: RecommendationRequest) {
        val client = ApiConfigLocal.getApiServiceLocal().getRecommendation(request)
        client.enqueue(object : Callback<RecommendationResponse> {
            override fun onResponse(
                call: Call<RecommendationResponse>,
                response: Response<RecommendationResponse>
            ) {
                if (response.isSuccessful) {
                    response.body()?.let {
                        _recommendations.postValue(it.recommendedProducts)
                    }
                }
            }

            override fun onFailure(call: Call<RecommendationResponse>, t: Throwable) {
                Log.e(ContentValues.TAG, "onFailure: ${t.message}")
            }
        })
    }

    companion object{
        private const val TAG = "DetailStoryViewModel"
    }
}