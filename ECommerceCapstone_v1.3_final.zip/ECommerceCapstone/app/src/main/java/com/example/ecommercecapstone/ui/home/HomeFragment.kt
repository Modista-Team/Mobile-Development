package com.example.ecommercecapstone.ui.home

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.ecommercecapstone.data.RecommendationRequest
import com.example.ecommercecapstone.data.adapter.ProductAdapter
import com.example.ecommercecapstone.data.adapter.RecommendationAdapter
import com.example.ecommercecapstone.data.api.ApiConfig
import com.example.ecommercecapstone.databinding.FragmentHomeBinding
import com.example.ecommercecapstone.ui.ViewModelFactory
import com.example.ecommercecapstone.ui.pencarian.PencarianActivity

class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!

    private lateinit var productAdapter: ProductAdapter
    private lateinit var recommendationAdapter: RecommendationAdapter
    private lateinit var homeViewModel: HomeViewModel

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val factory = ViewModelFactory.getInstance(requireContext())

        homeViewModel =
            ViewModelProvider(this, factory).get(HomeViewModel::class.java)

        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        val root: View = binding.root

        binding.pencarian.setOnClickListener {
            val intent = Intent(binding.root.context, PencarianActivity::class.java)
            startActivity(intent)
        }

        setupRecyclerView()

        val product = "360"
        val Product_ID = 360
        val Product_Description = "Polo Shirts"
        val Product_Category = "Womenswear"
        val Product_Line = "Trousers"
        val Raw_Material = "Fabrics"
        val Unit_Price = 37.7

        homeViewModel.getSession().observe(viewLifecycleOwner, Observer { user ->
            if (user.token != null) {
                ApiConfig.setAuthToken(user.token)
                Log.d("DEBUGGING", user.token)
                homeViewModel.fetchProductList()
                // Add this line to fetch recommendations
                homeViewModel.fetchRecommendations(RecommendationRequest(product, Product_ID, Product_Description, Product_Category, Product_Line, Raw_Material, Unit_Price))
            }
        })

        homeViewModel.productList.observe(viewLifecycleOwner, Observer {
            productAdapter.updateData(it)
        })

        homeViewModel.recommendations.observe(viewLifecycleOwner, Observer {
            recommendationAdapter.updateData(it)
        })

        return root
    }

    private fun setupRecyclerView() {
        productAdapter = ProductAdapter(emptyList())
        recommendationAdapter = RecommendationAdapter(emptyList()) // Initially, set an empty list
        binding.rvProduk.apply {
            adapter = productAdapter
            layoutManager = LinearLayoutManager(requireContext())
        }
        binding.rvRekomendasi.apply {
            adapter = recommendationAdapter
            layoutManager = LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
