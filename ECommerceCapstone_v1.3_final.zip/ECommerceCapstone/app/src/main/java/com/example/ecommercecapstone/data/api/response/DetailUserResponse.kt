package com.example.ecommercecapstone.data.api.response

import com.google.gson.annotations.SerializedName

data class DetailUserResponse (
    @field:SerializedName("id")
    val id: Int,
    @field:SerializedName("name")
    val name: String,
    @field:SerializedName("email")
    val email: String,
    @field:SerializedName("phone")
    val phone: String,
    @field:SerializedName("alamat")
    val alamat: String
)