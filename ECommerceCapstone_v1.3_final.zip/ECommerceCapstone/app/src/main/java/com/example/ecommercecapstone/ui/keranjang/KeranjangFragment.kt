package com.example.ecommercecapstone.ui.keranjang

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import android.graphics.drawable.ColorDrawable
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.ecommercecapstone.R
import com.example.ecommercecapstone.databinding.FragmentKeranjangBinding

class KeranjangFragment : Fragment() {

    private var _binding: FragmentKeranjangBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val keranjangViewModel =
            ViewModelProvider(this).get(KeranjangViewModel::class.java)

        _binding = FragmentKeranjangBinding.inflate(inflater, container, false)
        val root: View = binding.root

        (requireActivity() as AppCompatActivity).supportActionBar?.apply {
            title = "Keranjang Saya"
            setBackgroundDrawable(ColorDrawable(ContextCompat.getColor(requireContext(), R.color.main)))
        }

        // Set up quantity buttons
        setupQuantityButtons(root)

        return root
    }

    private fun setupQuantityButtons(view: View) {
        val quantityTextView1 = view.findViewById<TextView>(R.id.quantity1)
        val increaseButton1 = view.findViewById<ImageButton>(R.id.increase_quantity1)
        val decreaseButton1 = view.findViewById<ImageButton>(R.id.decrease_quantity1)

        increaseButton1.setOnClickListener {
            val currentQuantity = quantityTextView1.text.toString().toInt()
            quantityTextView1.text = (currentQuantity + 1).toString()
        }

        decreaseButton1.setOnClickListener {
            val currentQuantity = quantityTextView1.text.toString().toInt()
            if (currentQuantity > 1) {
                quantityTextView1.text = (currentQuantity - 1).toString()
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
