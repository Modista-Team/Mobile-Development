package com.example.ecommercecapstone.data

import androidx.lifecycle.liveData
import com.example.ecommercecapstone.data.api.ApiService
import com.example.ecommercecapstone.data.api.response.RegisterResponse
import com.google.gson.Gson
import retrofit2.HttpException

class RegisterRepository private constructor(
    private val apiService: ApiService
) {

    fun register(first_name: String, last_name: String, username: String, phone: String, address: String, email: String, password: String) = liveData {
        emit(ResultState.Loading)
        try {
            val successResponse = apiService.register(first_name, last_name, username, phone, address, email, password)
            emit(ResultState.Success(successResponse))
        } catch (e: HttpException) {
            val errorBody = e.response()?.errorBody()?.string()
            val errorResponse = Gson().fromJson(errorBody, RegisterResponse::class.java)
            emit(ResultState.Error(errorResponse.message ?: "Registration failed")) // Handle potential missing error message
        }
    }

    companion object {
        @Volatile
        private var instance: RegisterRepository? = null
        fun getInstance(apiService: ApiService) =
            instance ?: synchronized(this) {
                instance ?: RegisterRepository(apiService)
            }.also { instance = it }
    }
}