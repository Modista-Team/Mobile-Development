package com.example.ecommercecapstone.di

import com.example.ecommercecapstone.data.RegisterRepository
import com.example.ecommercecapstone.data.api.ApiConfig

object RegisterInjection {
    fun provideRepository(): RegisterRepository {
        val apiService = ApiConfig.getApiService()
        return RegisterRepository.getInstance(apiService)
    }
}