package com.example.ecommercecapstone.data.api.response

import com.google.gson.annotations.SerializedName

data class RegisterResponse (
    @field:SerializedName("success")
    val success: Boolean,
    @field:SerializedName("message")
    val message: String,
    @field:SerializedName("data")
    val data: Data
)

data class Data(
    @field:SerializedName("username")
    val username: String,
    @field:SerializedName("email")
    val email: String,
    @field:SerializedName("fullName")
    val fullName: String,
    @field:SerializedName("address")
    val address: String,
    @field:SerializedName("phone")
    val phone: String
)