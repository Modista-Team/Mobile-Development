package com.example.ecommercecapstone.data.api.response

import com.google.gson.annotations.SerializedName

data class ProductResponse(
    @SerializedName("product_id")
    val productId: Int,
    @SerializedName("product_name")
    val productName: String,
    @SerializedName("description")
    val description: String,
    @SerializedName("price")
    val price: String,
    @SerializedName("stock")
    val stock: Int,
    @SerializedName("image_url")
    val imageUrl: String,
    @SerializedName("created_at")
    val createdAt: String,
    @SerializedName("updated_at")
    val updatedAt: String,
    @SerializedName("category_id")
    val categoryId: Int
)