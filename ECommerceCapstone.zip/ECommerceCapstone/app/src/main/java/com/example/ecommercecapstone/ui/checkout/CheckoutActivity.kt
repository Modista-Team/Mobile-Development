package com.example.ecommercecapstone.ui.checkout

import android.content.Intent
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.MenuItem
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.ecommercecapstone.R
import com.example.ecommercecapstone.databinding.ActivityCheckoutBinding
import com.example.ecommercecapstone.databinding.ActivityDetailProdukBinding
import com.example.ecommercecapstone.ui.selesai.SelesaiActivity

class CheckoutActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCheckoutBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCheckoutBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.apply {
            setDisplayHomeAsUpEnabled(true)
            title = "Detail Pesanan"
            setBackgroundDrawable(ColorDrawable(ContextCompat.getColor(this@CheckoutActivity, R.color.main)))
        }

        setupAction()
    }

    private fun setupAction(){
        binding.btnBayar.setOnClickListener{
            val intent = Intent(this, SelesaiActivity::class.java)
            startActivity(intent)
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {  // Back button ID
                finish()  // Finish the current activity to go back
                return true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}