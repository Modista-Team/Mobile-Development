package com.example.ecommercecapstone.ui.register

import androidx.lifecycle.ViewModel
import com.example.ecommercecapstone.data.RegisterRepository
import com.example.ecommercecapstone.data.UserRepository

class RegisterViewModel(private val repository: RegisterRepository) : ViewModel() {
    fun register(first_name: String, last_name: String, username: String, phone: String, address: String, email: String, password: String) = repository.register(first_name, last_name, username, phone, address, email, password)
}