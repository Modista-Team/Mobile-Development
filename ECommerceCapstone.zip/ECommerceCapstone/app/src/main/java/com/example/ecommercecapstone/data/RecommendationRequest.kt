package com.example.ecommercecapstone.data

import com.google.gson.annotations.SerializedName

data class RecommendationRequest(
    @SerializedName("product")
    val product: String,
    @SerializedName("Product_ID")
    val productID: Int,
    @SerializedName("Product_Description")
    val productDescription: String,
    @SerializedName("Product_Category")
    val productCategory: String,
    @SerializedName("Product_Line")
    val productLine: String,
    @SerializedName("Raw_Material")
    val rawMaterial: String,
    @SerializedName("Unit_Price")
    val unitPrice: Double
)
