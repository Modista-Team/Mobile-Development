package com.example.ecommercecapstone.ui.home

import android.content.ContentValues.TAG
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import com.example.ecommercecapstone.data.ProductModel
import com.example.ecommercecapstone.data.RecommendationRequest
import com.example.ecommercecapstone.data.UserRepository
import com.example.ecommercecapstone.data.api.ApiConfig
import com.example.ecommercecapstone.data.api.ApiConfigLocal
import com.example.ecommercecapstone.data.api.ApiService
import com.example.ecommercecapstone.data.api.response.ListRecommendation
import com.example.ecommercecapstone.data.api.response.ProductResponse
import com.example.ecommercecapstone.data.api.response.RecommendationResponse
import com.example.ecommercecapstone.data.pref.UserModel
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class HomeViewModel(private val repository: UserRepository) : ViewModel() {

    private val _productList = MutableLiveData<List<ProductResponse>>()
    val productList: LiveData<List<ProductResponse>> get() = _productList

    private val _recommendations = MutableLiveData<List<ListRecommendation>>()
    val recommendations: LiveData<List<ListRecommendation>> get() = _recommendations

    init {
        fetchProductList()
    }

    fun fetchProductList() {

        val client = ApiConfig.getApiService().getProducts()
        client.enqueue(object : Callback<List<ProductResponse>> {
            override fun onResponse(
                call: Call<List<ProductResponse>>,
                response: Response<List<ProductResponse>>
            ) {
                if (response.isSuccessful) {
                    _productList.postValue(response.body())
                }
            }
            override fun onFailure(call: Call<List<ProductResponse>>, t: Throwable) {
                Log.e(TAG, "onFailure: ${t.message}")
            }
        })
    }

    fun fetchRecommendations(request: RecommendationRequest) {
        val client = ApiConfigLocal.getApiServiceLocal().getRecommendation(request)
        client.enqueue(object : Callback<RecommendationResponse> {
            override fun onResponse(
                call: Call<RecommendationResponse>,
                response: Response<RecommendationResponse>
            ) {
                if (response.isSuccessful) {
                    response.body()?.let {
                        _recommendations.postValue(it.recommendedProducts)
                    }
                }
            }

            override fun onFailure(call: Call<RecommendationResponse>, t: Throwable) {
                Log.e(TAG, "onFailure: ${t.message}")
            }
        })
    }

    // Function to get user session
    fun getSession(): LiveData<UserModel> {
        return repository.getSession().asLiveData()
    }
}