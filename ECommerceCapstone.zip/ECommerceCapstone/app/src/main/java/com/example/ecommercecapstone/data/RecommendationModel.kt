package com.example.ecommercecapstone.data

import com.google.gson.annotations.SerializedName

data class RecommendationModel (
    val productCategory: String,
    val productDescription: String,
    val productID: Int,
    val productLine: String,
    val rawMaterial: String,
    val similarityScore: Float,
    val unitPrice: Double
)