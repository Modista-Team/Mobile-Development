package com.example.ecommercecapstone.ui.profil

import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.view.animation.AnimationUtils
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.ecommercecapstone.R
import com.example.ecommercecapstone.databinding.FragmentProfilBinding
import com.example.ecommercecapstone.di.Injection
import com.example.ecommercecapstone.ui.ViewModelFactory

class ProfilFragment : Fragment() {

    private var _binding: FragmentProfilBinding? = null
    private val binding get() = _binding!!
    private lateinit var profilViewModel: ProfilViewModel

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val viewModelFactory = ViewModelFactory(Injection.provideRepository(requireActivity()))
        profilViewModel = ViewModelProvider(this, viewModelFactory).get(ProfilViewModel::class.java)

        _binding = FragmentProfilBinding.inflate(inflater, container, false)
        val root: View = binding.root

        // Atur ActionBar
        (requireActivity() as AppCompatActivity).supportActionBar?.apply {
            title = "Profil Saya"
            setBackgroundDrawable(ColorDrawable(ContextCompat.getColor(requireContext(), R.color.main)))
        }

        // Tambahkan MenuProvider untuk menangani menu logout
        setHasOptionsMenu(true) // Aktifkan opsi menu di fragment

        applyAnimations()

        return root
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.profil_menu, menu)
        super.onCreateOptionsMenu(menu, inflater)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.btn_logout -> {
                // Panggil fungsi logout dari ViewModel
                profilViewModel.logout()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun applyAnimations() {
        val slideInFromBottom = AnimationUtils.loadAnimation(requireContext(), R.anim.slide_in_from_bottom)

        binding.whiteBg.startAnimation(slideInFromBottom)
        binding.linearLayoutForm.startAnimation(slideInFromBottom)
        binding.linearLayoutNamaLengkap.startAnimation(slideInFromBottom)
        binding.textInputLayoutNamaLengkap.startAnimation(slideInFromBottom)
        binding.editTextNamaLengkap.startAnimation(slideInFromBottom)
        binding.linearLayoutEmail.startAnimation(slideInFromBottom)
        binding.textInputLayoutEmail.startAnimation(slideInFromBottom)
        binding.editTextTextEmail.startAnimation(slideInFromBottom)
        binding.linearLayoutPassword.startAnimation(slideInFromBottom)
        binding.textInputLayoutPassword.startAnimation(slideInFromBottom)
        binding.editTextTextPassword.startAnimation(slideInFromBottom)
        binding.linearLayoutNomorTelepon.startAnimation(slideInFromBottom)
        binding.textInputLayoutNomorTelepon.startAnimation(slideInFromBottom)
        binding.editTextNomorTelepon.startAnimation(slideInFromBottom)
        binding.linearLayoutAddress.startAnimation(slideInFromBottom)
        binding.textInputLayoutAddress.startAnimation(slideInFromBottom)
        binding.editTextAddress.startAnimation(slideInFromBottom)
    }

    private fun setupAction() {
        binding.editTextTextPassword.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                // No operation
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                // No operation
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                if (s.toString().length < 8) {
                    binding.editTextTextPassword.error = "Password tidak boleh kurang dari 8 karakter"
                } else {
                    binding.editTextTextPassword.error = null
                }
            }
        })
    }
}
