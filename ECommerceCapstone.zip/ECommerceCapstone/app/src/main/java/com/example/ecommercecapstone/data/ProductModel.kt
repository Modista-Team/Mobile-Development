package com.example.ecommercecapstone.data

data class ProductModel(
    val productId: Int,
    val productName: String,
    val description: String,
    val price: String,
    val stock: Int,
    val imageUrl: String,
    val createdAt: String,
    val updatedAt: String,
    val categoryId: Int
)
