package com.example.ecommercecapstone.ui.detailProduk

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.example.ecommercecapstone.data.RecommendationRequest
import com.example.ecommercecapstone.data.api.ApiConfig
import com.example.ecommercecapstone.databinding.ActivityDetailProdukBinding
import com.example.ecommercecapstone.ui.ViewModelFactory
import com.example.ecommercecapstone.ui.checkout.CheckoutActivity
import com.example.ecommercecapstone.ui.login.LoginViewModel
import kotlin.properties.Delegates

class DetailProdukActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailProdukBinding
    private var id by Delegates.notNull<Int>()
    private val viewModel by viewModels<DetailProdukViewModel> {
        ViewModelFactory.getInstance(this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailProdukBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.hide()

        setupAction()
        setupViewModel()

        id = intent.getIntExtra("id", 0)
    }

    private fun setupAction(){
        binding.btnBeli.setOnClickListener{
            val intent = Intent(this, CheckoutActivity::class.java)
            startActivity(intent)
        }
    }

    private fun setupViewModel() {
        viewModel.isLoading.observe(this) {
            binding.progressBar.visibility = if (it.equals(true)) View.VISIBLE else View.GONE
        }

        viewModel.getSession().observe(this) { user ->
            if (user.token != null) {
                ApiConfig.setAuthToken(user.token)
                Log.d("DEBUGGING", user.token)
                viewModel.getDetailProduct(this.id)
            }
        }

        viewModel.detailProductName.observe(this){
            binding.tvNamaProduk.text = it
        }

        viewModel.detailProductStock.observe(this){
            binding.tvStokQty.text = it.toString()
        }

        viewModel.detailProductPrice.observe(this){
            binding.tvHarga.text = it
        }

        viewModel.detailProductDescription.observe(this){
            binding.tvIsiDeskripsi.text = it
        }

        viewModel.detailProductPhotoUrl.observe(this){
            Glide.with(this)
                .load(it)
                .into(binding.detailPhoto)
        }
    }

    companion object {
        const val ID = "id"
    }
}