package com.example.ecommercecapstone.data.adapter

import android.app.Activity
import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.app.ActivityOptionsCompat
import androidx.core.util.Pair
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.ecommercecapstone.R
import com.example.ecommercecapstone.data.ProductModel
import com.example.ecommercecapstone.data.api.response.ProductResponse
import com.example.ecommercecapstone.databinding.ItemRowProdukBinding
import com.example.ecommercecapstone.ui.detailProduk.DetailProdukActivity

class ProductAdapter(private var productList: List<ProductResponse>) :
    RecyclerView.Adapter<ProductAdapter.ProductViewHolder>() {

    inner class ProductViewHolder(private val binding: ItemRowProdukBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(product: ProductResponse) {
            binding.tvItemName.text = product.productName
            Glide.with(binding.root.context)
                .load(product.imageUrl)
                .into(binding.imgItemPhoto)

            itemView.setOnClickListener {
                val intent = Intent(itemView.context, DetailProdukActivity::class.java)
                intent.putExtra(DetailProdukActivity.ID, product.productId)

                val optionsCompat: ActivityOptionsCompat =
                    ActivityOptionsCompat.makeSceneTransitionAnimation(
                        itemView.context as Activity,
                        Pair(binding.imgItemPhoto, "Foto"),
                        Pair(binding.tvItemName, "Nama")
                    )

                itemView.context.startActivity(intent, optionsCompat.toBundle())
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProductViewHolder {
        val binding =
            ItemRowProdukBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ProductViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ProductViewHolder, position: Int) {
        holder.bind(productList[position])
    }

    override fun getItemCount(): Int {
        return productList.size
    }

    fun updateData(newProducts: List<ProductResponse>) {
        productList = newProducts
        notifyDataSetChanged()
    }
}