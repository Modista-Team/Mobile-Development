package com.example.ecommercecapstone.data.api.response

import com.google.gson.annotations.SerializedName

data class RecommendationResponse (
    @field:SerializedName("recommended_products")
    val recommendedProducts: List<ListRecommendation>,
    @field:SerializedName("user_input")
    val userInput: UserInput
)

data class ListRecommendation(
    @SerializedName("Product_Category")
    val productCategory: String,
    @SerializedName("Product_Description")
    val productDescription: String,
    @SerializedName("Product_ID")
    val productID: Int,
    @SerializedName("Product_Line")
    val productLine: String,
    @SerializedName("Raw_Material")
    val rawMaterial: String,
    @SerializedName("Similarity Score")
    val similarityScore: Float,
    @SerializedName("Unit_Price")
    val unitPrice: Double
)

data class UserInput(
    @SerializedName("Product_Category")
    val productCategory: String,
    @SerializedName("Product_Description")
    val productDescription: String,
    @SerializedName("Product_ID")
    val productID: Int,
    @SerializedName("Product_Line")
    val productLine: String,
    @SerializedName("Raw_Material")
    val rawMaterial: String,
    @SerializedName("Unit_Price")
    val unitPrice: Double
)