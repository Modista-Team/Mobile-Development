package com.example.ecommercecapstone.ui.pencarian

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.example.ecommercecapstone.R
import com.example.ecommercecapstone.databinding.ActivityPencarianBinding
import com.example.ecommercecapstone.ui.home.HomeFragment
import com.example.ecommercecapstone.ui.keranjang.KeranjangFragment

class PencarianActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPencarianBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPencarianBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.hide()

        // Set up back button listener
        binding.btnBack.setOnClickListener {
            navigateToFragment(HomeFragment())
        }

        // Set up keranjang button listener
        binding.btnKeranjang.setOnClickListener {
            navigateToFragment(KeranjangFragment())
        }
    }

    private fun navigateToFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, fragment)
            .addToBackStack(null)
            .commit()
    }
}
